<p>{{ trans('core/setting::setting.test_email_description') }}</p>

<div class="form-group mb-3">
    <input type="email" class="form-control" name="email" placeholder="{{ trans('core/setting::setting.test_email_input_placeholder') }}">
</div>
