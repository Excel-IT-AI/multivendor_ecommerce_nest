<div class="form-group mb-3 col-12">
    <div class="form-actions">
        <div class="btn-set text-center">
            <button type="submit" name="submit" value="submit" class="btn btn-success">
                <i class="fa fa-check-circle"></i> {{ trans('core/acl::users.update') }}
            </button>
        </div>
    </div>
</div>
