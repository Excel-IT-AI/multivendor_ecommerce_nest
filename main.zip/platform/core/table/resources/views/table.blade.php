@extends(BaseHelper::getAdminMasterLayoutTemplate())
@section('content')
    @include('core/table::base-table')
@stop
