<?php

if (!defined('DASHBOARD_FILTER_ADMIN_LIST')) {
    define('DASHBOARD_FILTER_ADMIN_LIST', 'admin_dashboard_list');
}

if (!defined('DASHBOARD_ACTION_REGISTER_SCRIPTS')) {
    define('DASHBOARD_ACTION_REGISTER_SCRIPTS', 'dashboard_register_scripts');
}


if (!defined('DASHBOARD_FILTER_ADMIN_NOTIFICATIONS')) {
    define('DASHBOARD_FILTER_ADMIN_NOTIFICATIONS', 'admin_dashboard_notifications');
}

if (!defined('DASHBOARD_FILTER_TOP_BLOCKS')) {
    define('DASHBOARD_FILTER_TOP_BLOCKS', 'admin_dashboard_top_blocks');
}
